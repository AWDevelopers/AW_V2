<!DOCTYPE html>
<html>
<head>
	<title>Voluntarios ONGS</title>
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
		<link rel="stylesheet" type="text/css" href="css/colorsandtext.css"/>
	<!--<link rel="stylesheet" type="text/css" href="css/voluntarios.css" >-->

</head>
<body>
	<div id='contenedor'>
		<!--Aqui va el menu y la cabecera que es comun-->
		<?php require 'common.php'; ?>
		
		<!--Aqui va el contenido-->
		<div class="contenido">

				<div class="cajaTitulos"> Nombres </div>
				<div class="cajaTitulos"> Horas disponibles </div>
				<div class="contenidoVoluntario">
					<div class="imagenUsuario"> <img src="img/usuarioSF.png"></div>
					<div class="nombreUsuario"> NOMBRE DEL USUARIO 16</div>
					<div class="nombreUsuario"> 10 h </div>
					<div class="boton"> <button> Apuntar </button> </div>
				</div>
				
				<div class="contenidoVoluntario">
					<div class="imagenUsuario"> <img src="img/usuarioSF.png"></div>
					<div class="nombreUsuario"> NOMBRE DEL USUARIO 2</div>
					<div class="nombreUsuario"> 10 h </div>
					<div class="boton"> <button> Apuntar </button> </div>
				</div>
				
				<div class="contenidoVoluntario">
					<div class="imagenUsuario"> <img src="img/usuarioSF.png"></div>
					<div class="nombreUsuario"> NOMBRE DEL USUARIO 3</div>
					<div class="nombreUsuario"> 10 h </div>
					<div class="boton"> <button> Apuntar </button> </div>
				</div>
				
				
				
				
		</div>
			

		</div>
	</div>
</body>
</html>