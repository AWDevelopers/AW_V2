<?php include('includes/config.php'); ?>
<?php require_once('./includes/comun/cabecera.php');?>
<?php require_once('./includes/comun/siderbarLeft.php');?>